"""CED Graph v2 live writer.

Turns live debate output into graph-native epistemic objects:
agent answer -> claim
structured parser -> evidence / assumptions / objections / uncertainty / revisions
opposition -> contradiction edge
"""

from __future__ import annotations

import hashlib
import re
from typing import Iterable

from backend.epistemic.claim import Claim, Evidence
from backend.epistemic.epistemic_graph import EdgeType, EpistemicGraph, NodeType
from backend.epistemic.epistemic_state import EpistemicState, IllegalTransition
from backend.orchestrator.epistemic_scoring import EpistemicScoreBreakdown, EpistemicScoringEngine
from backend.orchestrator.structured_epistemic_parser import (
    ParsedEpistemicAnswer,
    StructuredEpistemicParser,
)


PARSER = StructuredEpistemicParser()
SCORER = EpistemicScoringEngine()


EVIDENCE_MARKERS = StructuredEpistemicParser.EVIDENCE_MARKERS

OPPOSITION_MARKERS = (
    "not",
    "never",
    "no ",
    "false",
    "incorrect",
    "wrong",
    "disagree",
    "contradicts",
    "opposes",
)

OPPOSITION_PAIRS = (
    ("is", "is not"),
    ("are", "are not"),
    ("can", "cannot"),
    ("can", "can not"),
    ("should", "should not"),
    ("true", "false"),
    ("process", "final answer"),
    ("revisable", "fixed"),
    ("dynamic", "static"),
)


def write_answer_to_graph(session, claim_id: str, model_id: str, text: str, round_num: int) -> dict:
    """Attach structured epistemic objects for a freshly recorded live claim."""
    graph: EpistemicGraph = session.epistemic_graph
    claim = graph.claims[claim_id]
    parsed = PARSER.parse(text)

    evidence_count = 0
    for snippet in parsed.supporting_evidence or _extract_evidence_snippets(text):
        _attach_evidence(graph, claim, snippet, source=model_id, round_num=round_num)
        evidence_count += 1

    gap_count = 0
    if evidence_count == 0:
        _record_evidence_gap(graph, claim, model_id, round_num)
        gap_count = 1

    structured_counts = _attach_structured_nodes(graph, claim, parsed, model_id, round_num)
    contradiction_count = _link_live_contradictions(graph, claim, model_id, round_num)

    score = SCORER.apply_score(graph, claim, parsed)
    _refresh_claim_payload(graph, claim, parsed, score)

    return {
        "claim_id": claim_id,
        "evidence_count": evidence_count,
        "evidence_gap_count": gap_count,
        "contradiction_count": contradiction_count + structured_counts["contradictions"],
        "structured_counts": structured_counts,
        "uncertainty_level": parsed.uncertainty_level,
        "epistemic_score": score.score,
        "confidence_after": score.confidence_after,
        "confidence_level": score.confidence_level,
    }


def _attach_structured_nodes(
    graph: EpistemicGraph,
    claim: Claim,
    parsed: ParsedEpistemicAnswer,
    model_id: str,
    round_num: int,
) -> dict:
    counts = {
        "main_claims": len(parsed.main_claims),
        "assumptions": 0,
        "objections": 0,
        "contradictions": 0,
        "revision_suggestions": 0,
    }

    for assumption in parsed.assumptions:
        node_id = graph.add_node(
            NodeType.HYPOTHESIS,
            assumption[:320],
            payload={
                "category": "assumption",
                "claim_id": claim.claim_id,
                "source_model": model_id,
                "round": round_num,
                "parser_version": StructuredEpistemicParser.VERSION,
            },
        )
        graph.link(claim.claim_id, node_id, EdgeType.DEPENDS_ON, weight=0.45)
        counts["assumptions"] += 1

    for objection in parsed.objections:
        node_id = graph.add_node(
            NodeType.OPEN_PROBLEM,
            objection[:320],
            payload={
                "category": "objection",
                "claim_id": claim.claim_id,
                "source_model": model_id,
                "round": round_num,
                "parser_version": StructuredEpistemicParser.VERSION,
            },
        )
        graph.link(node_id, claim.claim_id, EdgeType.CONTRADICTS, weight=0.55)
        counts["objections"] += 1

    for contradiction in parsed.contradictions:
        node_id = graph.add_node(
            NodeType.CONTRADICTION,
            contradiction[:320],
            payload={
                "category": "self_contradiction_or_dispute",
                "claim_id": claim.claim_id,
                "source_model": model_id,
                "round": round_num,
                "parser_version": StructuredEpistemicParser.VERSION,
            },
        )
        graph.link(node_id, claim.claim_id, EdgeType.CONTRADICTS, weight=0.65)
        counts["contradictions"] += 1

    for suggestion in parsed.revision_suggestions:
        node_id = graph.add_node(
            NodeType.PROCEDURE,
            suggestion[:320],
            payload={
                "category": "revision_suggestion",
                "claim_id": claim.claim_id,
                "source_model": model_id,
                "round": round_num,
                "parser_version": StructuredEpistemicParser.VERSION,
            },
        )
        graph.link(node_id, claim.claim_id, EdgeType.REFINES, weight=0.5)
        counts["revision_suggestions"] += 1

    return counts


def _extract_evidence_snippets(text: str) -> list[str]:
    snippets: list[str] = []
    for sentence in _sentences(text):
        lower = sentence.lower()
        if any(marker in lower for marker in EVIDENCE_MARKERS):
            snippets.append(sentence[:320])
        if len(snippets) >= 3:
            break
    return snippets


def _sentences(text: str) -> Iterable[str]:
    for sentence in re.split(r"(?<=[.!?])\s+", text.strip()):
        sentence = sentence.strip()
        if len(sentence) >= 20:
            yield sentence


def _stable_evidence_id(claim_id: str, summary: str, source: str) -> str:
    digest = hashlib.sha256(f"{claim_id}|{source}|{summary}".encode("utf-8")).hexdigest()[:12]
    return f"ev_{digest}"


def _attach_evidence(graph: EpistemicGraph, claim: Claim, summary: str, source: str, round_num: int) -> None:
    ev = Evidence(
        evidence_id=_stable_evidence_id(claim.claim_id, summary, source),
        summary=summary,
        source=source,
        quality=0.35,
        supports=True,
    )

    if all(existing.evidence_id != ev.evidence_id for existing in claim.evidence):
        claim.add_evidence(ev)

    evidence_node_id = graph.add_node(
        NodeType.EVIDENCE,
        summary[:320],
        payload={
            "claim_id": claim.claim_id,
            "source_model": source,
            "round": round_num,
            "quality": ev.quality,
            "supports": True,
            "evidence_id": ev.evidence_id,
            "parser_version": StructuredEpistemicParser.VERSION,
        },
    )
    graph.link(evidence_node_id, claim.claim_id, EdgeType.SUPPORTS, weight=ev.quality)

    try:
        if claim.state == EpistemicState.HYPOTHESIS:
            claim.transition(
                EpistemicState.SUPPORTED,
                actor="ced_live_writer",
                reason="Live answer contained evidence/provenance marker.",
            )
    except IllegalTransition:
        pass


def _record_evidence_gap(graph: EpistemicGraph, claim: Claim, model_id: str, round_num: int) -> None:
    gap_node_id = graph.add_node(
        NodeType.OPEN_PROBLEM,
        f"Evidence gap for claim {claim.claim_id}",
        payload={
            "claim_id": claim.claim_id,
            "source_model": model_id,
            "round": round_num,
            "reason": "No explicit evidence/provenance marker detected in live answer.",
            "parser_version": StructuredEpistemicParser.VERSION,
        },
    )
    graph.link(claim.claim_id, gap_node_id, EdgeType.DEPENDS_ON, weight=0.5)


def _link_live_contradictions(graph: EpistemicGraph, latest: Claim, model_id: str, round_num: int) -> int:
    linked = 0
    for previous in list(graph.claims.values()):
        if previous.claim_id == latest.claim_id:
            continue
        if previous.author_model == model_id:
            continue

        reason = _explain_if_contradiction(previous.text, latest.text)
        if not reason:
            continue
        if _has_contradiction_edge(graph, previous.claim_id, latest.claim_id):
            continue

        graph.record_contradiction(previous.claim_id, latest.claim_id)
        linked += 1

        contradiction_node_id = graph.add_node(
            NodeType.CONTRADICTION,
            reason,
            payload={
                "claim_a": previous.claim_id,
                "claim_b": latest.claim_id,
                "round": round_num,
                "detected_by": "ced_live_writer",
                "parser_version": StructuredEpistemicParser.VERSION,
            },
        )
        graph.link(contradiction_node_id, latest.claim_id, EdgeType.CONTRADICTS, weight=0.7)

        try:
            if latest.state == EpistemicState.SUPPORTED:
                latest.transition(
                    EpistemicState.DISPUTED,
                    actor="ced_live_writer",
                    reason=reason,
                )
            elif latest.state == EpistemicState.HYPOTHESIS:
                latest.transition(
                    EpistemicState.CHALLENGED,
                    actor="ced_live_writer",
                    reason=reason,
                )
        except IllegalTransition:
            pass

    return linked


def _has_contradiction_edge(graph: EpistemicGraph, left: str, right: str) -> bool:
    pair = {left, right}
    for edge in graph.edges.values():
        edge_type = getattr(edge.edge_type, "value", edge.edge_type)
        if edge_type == "contradicts" and {edge.src, edge.dst} == pair:
            return True
    return False


def _explain_if_contradiction(text_a: str, text_b: str) -> str:
    a = _normalize(text_a)
    b = _normalize(text_b)

    for positive, negative in OPPOSITION_PAIRS:
        if _contains_word(a, positive) and _contains_phrase(b, negative):
            return f"Live opposition detected: '{positive}' vs '{negative}'."
        if _contains_phrase(a, negative) and _contains_word(b, positive):
            return f"Live opposition detected: '{negative}' vs '{positive}'."

    if any(marker in b for marker in OPPOSITION_MARKERS):
        overlap = _token_overlap(a, b)
        if overlap >= 0.18:
            return "Live answer appears to negate or dispute an earlier claim."

    return ""


def _normalize(text: str) -> str:
    return " ".join(text.lower().replace("n't", " not").split())


def _contains_phrase(text: str, phrase: str) -> bool:
    return phrase in text


def _contains_word(text: str, word: str) -> bool:
    return re.search(rf"\b{re.escape(word)}\b", text) is not None


def _token_overlap(left: str, right: str) -> float:
    left_words = {w for w in re.findall(r"[a-zA-Z]{4,}", left)}
    right_words = {w for w in re.findall(r"[a-zA-Z]{4,}", right)}
    if not left_words or not right_words:
        return 0.0
    return len(left_words & right_words) / max(len(left_words | right_words), 1)


def _refresh_claim_payload(
    graph: EpistemicGraph,
    claim: Claim,
    parsed: ParsedEpistemicAnswer | None = None,
    score: EpistemicScoreBreakdown | None = None,
) -> None:
    node = graph.nodes.get(claim.claim_id)
    if node is None:
        return
    payload = dict(node.payload or {})
    payload.update({
        "state": claim.state.value,
        "confidence": round(claim.confidence, 3),
        "evidence_count": len(claim.evidence),
        "evidence_quality": round(claim.evidence_quality, 3),
        "contradiction_count": len(claim.contradictions),
        "has_been_challenged": claim.has_been_challenged,
        "revision_count": len(claim.revision_history),
        "structured_parser_version": StructuredEpistemicParser.VERSION,
    })

    if parsed is not None:
        payload.update({
            "uncertainty_level": parsed.uncertainty_level,
            "uncertainty_score": parsed.uncertainty_score,
            "structured_counts": {
                "main_claims": len(parsed.main_claims),
                "supporting_evidence": len(parsed.supporting_evidence),
                "assumptions": len(parsed.assumptions),
                "objections": len(parsed.objections),
                "contradictions": len(parsed.contradictions),
                "revision_suggestions": len(parsed.revision_suggestions),
            },
            "structured_parser": parsed.to_dict(),
        })

    if score is not None:
        payload.update({
            "epistemic_score": score.to_dict(),
            "confidence_level": score.confidence_level,
            "scoring_engine_version": EpistemicScoringEngine.VERSION,
        })

    node.payload = payload
