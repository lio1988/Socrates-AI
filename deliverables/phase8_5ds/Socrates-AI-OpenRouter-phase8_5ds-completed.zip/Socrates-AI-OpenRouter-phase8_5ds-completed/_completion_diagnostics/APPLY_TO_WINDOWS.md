# Apply the Phase 8.5D-S completion to the Windows checkout

The completion was produced from the uploaded source snapshot. The archive did
not include `.git`, so no authentic commit was created by the assistant.

## Recommended method: copy only the changed files

1. Keep the original repository at:
   `C:\Users\spirc\Desktop\Socrates-AI-OpenRouter`
2. Extract `Socrates-AI-OpenRouter-phase8_5ds-completed.zip` to a temporary
   directory.
3. Copy the files listed in `_completion_diagnostics\changed_files.txt` from
   the extracted snapshot over the same relative paths in the original
   repository.
4. Do not touch the protected untracked files:
   - `scripts\live_dialogue.py.bak`
   - the malformed root filename beginning `ocratic_followup_mandate`
5. In PowerShell, from the original repository, run:

```powershell
cd "C:\Users\spirc\Desktop\Socrates-AI-OpenRouter"

.\.venv\Scripts\python.exe -m pytest -q `
  tests_dialogues/test_socrates_zero_openrouter_acquisition_wire_spec_evidence_v1_contracts.py `
  tests_dialogues/test_socrates_zero_openrouter_wire_spec_source_acquisition_v1.py `
  tests_dialogues/test_socrates_zero_openrouter_wire_spec_manifest_v1.py

git diff --check
git status --short --branch
```

Expected focused result: `29 passed`.

Then inspect and commit:

```powershell
git add -- `
  backend/dialogues/socrates_zero/openrouter_wire_spec_source_v1.py `
  backend/dialogues/socrates_zero/openrouter_wire_spec_manifest_v1.py `
  scripts/acquire_socrates_zero_openrouter_wire_spec_sources_v1.py `
  scripts/build_socrates_zero_openrouter_wire_spec_manifest_v1.py `
  tests_dialogues/test_socrates_zero_openrouter_acquisition_wire_spec_evidence_v1_contracts.py `
  tests_dialogues/test_socrates_zero_openrouter_wire_spec_source_acquisition_v1.py `
  tests_dialogues/test_socrates_zero_openrouter_wire_spec_manifest_v1.py `
  docs/SOCRATES_ZERO_OPENROUTER_WIRE_SPECIFICATION_MANIFEST_V1.md `
  docs/branches/feature-socrates-zero-openrouter-wire-spec-evidence-v1

git diff --cached --check
git commit -m "data: complete falsified OpenRouter wire specification manifest v1"
```

## Patch method

The supplied `.patch` is relative to the original uploaded snapshot. Because
some files were already uncommitted in the user's checkout, `git apply` may
report conflicts. Use the copy method above if that happens.
