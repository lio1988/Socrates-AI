# feature/socrates-zero-search-v0

## Durable facts

- Canonical engine: `backend/dialogues/ced.py`, especially
  `CEDOrchestrator.run_registry_session`.
- Fixed rotation: `_PHASE_INDEX`, `_PHASE_ROLE_SLOTS`,
  `_PHASE_ALL_AGENTS_ROLE`, and `assign_roles_for_phase`.
- Hybrid epistemic core is the sole support/release authority; scores,
  ratification, search, and learning may not manufacture support.
- Existing deliberation-tree search is an optional UCB synthesis-revision
  mechanism, not SocratesZero epistemic MCTS.
- `AgentTask.task_id` is random historical identity. Current accepted move IDs
  are deterministic but not yet the full versioned replay identity requested by
  SocratesZero.
- Provider failures remain failures; exact actual-model identity is a protocol
  fact; no silent substitution or fabricated output is permitted.
- Provider-envelope success is not CED acceptance. Socratic content is checked
  phase-aware at the CED boundary before accepted move identity is assigned.
- `marker_is_contracted(task_kind)` is the single prompt/parser authority for
  epistemic-marker presence. Marker data remains advisory and non-governing.
- Legacy graph/CBE/Dung components are non-governing and must not be wired into
  the new search path as authority.
- The current SocratesZero package is a runtime-inert research surface: no
  runtime flag reader, execution, provider call, learning, PyTorch, GPU, or
  CUDA. Its PUCT implementation is standalone experimental search only.
- `CanonicalTaskSpec` is the single read-only fixed-orchestration extraction;
  `_run_registry_phase()` consumes it, so the baseline adapter copies no
  rotation business logic.
- `backend/dialogues/ced_search_projection.py` is a trusted CED-side bridge.
  It may read governing records and emit frozen digests; the search package is
  forbidden from importing the Hybrid core directly.
- SearchState projection includes only recorded/validated source material.
  Provider receipts remain absent when exact canonical observation records are
  unavailable; no completeness is fabricated.
- The initial hard vocabulary is: Socratic question, initial proposal, generic
  elenchus, targeted challenge, reflection, targeted defence, reconstruction,
  final synthesis, ratification, and terminal stop.
- The fixed baseline is proven inside the legal set for actual canonical phase
  prefixes from Opening through Synthesis.
- Phase-2 semantic surfaces are separately versioned as
  `ced-search-state-projection/v0`, `ced-fixed-rotation-adapter/v0`,
  `ced-legal-action-vocabulary/v0`, and
  `ced-deterministic-legal-action-generator/v0`.
- `final_response` before canonical `DialogPhase.COMPLETE` is inconsistent
  source state and the projection must fail closed.
- Constitution owns legality; Policy may rank only the supplied legal set and
  cannot call back into `legal_actions()`, generate actions, or execute one.
- `HeuristicPolicyPrior` v0 is deterministic and model-free. It uses only three
  public signal families: unresolved contradiction, unresolved question, and
  valid canonical claim target. Every applied delta has a structured reason
  code, and no score, consensus, marker, provider identity, or prose heuristic
  is admitted.
- Every heuristic-supported action retains final probability at least `1e-6`;
  singleton input maps to `1.0`, empty input stays empty, and
  `UniformPolicyPrior` is the versioned `1/N` reference.
- Value consumes one current valid SearchState only. It cannot call Policy,
  Constitution, providers, future episode outcomes, benchmark labels, or reward.
- `NeutralValueEstimator` v0 returns `0.0`. `HeuristicValueEstimator` v0 is
  penalty-only: unresolved contradictions (`-0.08`, floor `-0.24`), unresolved
  questions (`-0.05`, floor `-0.20`), blocked terminal (`-0.20`), and exhausted
  budget (`-0.10`). Answer-ready and abstained states are neutral.
- Opaque verification digests, evidence count, consensus, scores, markers,
  provider/model identity, prose, Policy context, and candidate-answer polish
  are forbidden Value signals. Positive verified/resolved progress must remain
  unavailable until SearchState exposes canonical outcome semantics.
- Value range is `[-1,+1]`; structural invalidity raises rather than becoming
  `-1`. Each evaluation has a deterministic structured component audit/hash.
- `GreedyStrategy` v0 requires the complete hard-legal generated set and selects
  Policy argmax with an action-ID tie-break. Root Value remains separate from
  action statistics; no successor or action-conditioned value is fabricated.
- A genuine Best-of-N required an additive transition seam absent from Phase 1.
  `ActionSuccessor` binds one action to one immutable successor SearchState and
  exact branch-local usage; injected `SuccessorStateEvaluator` has no execution
  or governing authority.
- `BestOfNStrategy` v0 freezes maximum `N=4`, caps candidates by remaining
  nodes/expansions/depth, aggregates exact sibling usage, and selects by
  successor Value, Policy prior, then action ID.
- Best-of-N receipts preserve the deterministic positional mapping
  `expanded_action_ids[i] -> visited_state_ids[i+1]`. No canonical successor
  evaluator/executor, shadow integration, or candidate event schema exists yet.
- `SuccessorStateEvaluator` guarantees only an async action-linked
  `ActionSuccessor` plus branch-local usage. It declares no determinism,
  isolation, recursive capability, failure record, or canonical executor; no
  repository implementation establishes safe descendant reuse.
- `PUCTStrategy` is `puct-strategy/v0`; its immutable config is
  `puct-config/v0`, canonical untuned `c_puct=1.0`, allowed range `(0,100]`.
- PUCT v0 is hard-frozen to one real ply relative to the root even when
  `SearchBudget.max_depth` is larger. Every simulation calls the experimental
  evaluator from the immutable root and consumes exactly one real node and one
  expansion; there are no cached pseudo-visits or imagined descendants.
- Selection is `Q + c_puct * P * sqrt(max(1,N)) / (1+N_a)`, with score, prior,
  then action-ID ties. Root selection uses visits, Q, prior, then action ID.
  Q is the undiscounted mean of observed successor V values in one epistemic
  orientation: no player sign flip and no hidden discount.
- All hard-legal root edges are registered. Repeated observations allocate
  compute adaptively; a lower-prior branch can overturn Policy when observed V
  and budget justify it. Policy and Value still cannot change legality.
- Identical successor state IDs retain path-local nodes/statistics. Duplicate
  IDs are receipt diagnostics only; v0 has no shared transposition table.
- The frozen canonical `SearchReceipt` remains unchanged. `PUCTSearchReceipt`
  (`puct-search-receipt/v0`) is a linked immutable companion containing config,
  dependency identities, nodes, edges, simulations, priors, N/Q, successors,
  Values, usage, tie rules, duplicates, and termination. `search()` returns the
  canonical `SearchResult`; `evaluate()` returns it with the rich receipt.
- Structural budget capacity is checked before evaluator work. The evaluator
  receives aggregate usage and owns pre-work reservation for model/tool/token/
  cost/time deltas unknowable to the strategy; returned deltas are revalidated
  branch-locally and in aggregate. Exceptions invalidate the entire v0 search.
- A terminal PUCT root is neither expanded nor observed and returns no
  fabricated Stop selection. No PUCT output is wired into production CED.
- Phase 5 is frozen as `socrateszero-search-kernel-eval-harness/v0` over
  `socrateszero-search-kernel-case-set/v0`: 20 deterministic cases, exactly two
  in each of ten precommitted categories, and budgets
  `matched-successor-budget/v0/{1,2,4,8}`.
- Strategy-facing fixtures contain no ground truth, outcome, optimum,
  case/category label, or label-derived case ID. Two such label leaks were
  found and separately fixed before the first comparative run; no result was
  generated against either defective surface.
- The fixture successor independently checks monotone aggregate usage. Harness
  accounting does not trust the strategy receipt, and adversarial overuse is a
  visible failure. Every valid observation costs one node and one expansion;
  provider/tool/token/cost/time counters are exactly zero.
- Frozen matched heuristic-Policy/heuristic-Value result at cap four: Greedy
  `9/20`, regret `11.55`, zero successors; BestOfN `15/20`, regret `4.80`, 62
  successors; PUCT `15/20`, regret `4.55`, 80 successors. BestOfN and PUCT tie
  on 18 cases and each wins one selective-budget case.
- Frozen PUCT sweep `(budget, correct, regret, successors)` is
  `(1,9,11.55,20)`, `(2,12,7.75,40)`, `(4,15,4.55,80)`, and
  `(8,12,7.75,160)`. Budget eight is deliberately preserved as worse than
  budget four; there was no post-result tuning.
- Under Neutral Value, Uniform Policy scores `10/20` while Heuristic Policy
  scores `9/20` for both Greedy and PUCT-4. With Heuristic Policy fixed,
  Heuristic Value raises BestOfN and PUCT from `9/20` to `15/20`, while Greedy
  remains unchanged because its decision is Policy-only.
- The immutable artifact ID is
  `szevalartifact_dc795fdef6b64e56b808b990fedd764def7c6e1858d178d29c26aa3280ede710`.
  Re-execution is byte-identical after newline normalization.
- Both inspected saved traces lack honest alternative-action outcomes:
  evaluable replay cases `0`, explicit missing counterfactuals `2`.
- Phase 5 evidence is search-kernel-only. It establishes no end-to-end CED or
  Socrates dialogue improvement and grants no production authority.
- Phase 5.5 verified the artifact SHA-256 and byte equality with the Git blob
  first committed by `17be287`, then reconstructed all 11 configurations
  directly from the machine-readable artifact without rewriting it.
- The only matched Heuristic-Policy versus Uniform-Policy pairs are Greedy and
  PUCT-4 under Neutral Value. Both have 6 improved, 8 worsened, and 6 unchanged
  cases; Heuristic loses one correct case and adds 2.30 regret. Phase 5.5
  classifies `HeuristicPolicyPrior/v0` as `HARMFUL` in this regime.
- With Heuristic Policy fixed, Heuristic Value changes Greedy by zero, adds six
  correct cases and removes 6.95 regret for BestOfN, and adds six correct cases
  and removes 7.00 regret for PUCT. Value is the strongest demonstrated
  contributor beyond Policy-only selection.
- Greedy H/H to BestOfN-4 H/H yields `+6` correct and `-6.75` regret at 62
  successor observations. BestOfN-4 to PUCT-4 yields `0` correct and `-0.25`
  regret at 18 additional observations. Most measured gain is successor
  observation plus Value, not adaptive PUCT allocation.
- The three PUCT-4 to PUCT-8 regressions are caused by visit-count-first root
  selection after redundant deterministic one-ply re-observations. Budget four
  ties all actions at one visit and Q selects the optimum; budget eight gives
  high-prior actions more visits and selects them despite worse Q. No invariant
  violation or possible bug was found.
- Both value-uninformative fixtures expose zero successor contradictions,
  questions, and terminal differences; all successor Values are exactly zero.
  Their distinct utilities are evaluator-only future labels and cannot lawfully
  be recovered from action digests.
- Real SearchState v0 is nevertheless information-starved: Hybrid owns typed
  verification results, claim assessments, objection/contradiction lifecycle,
  and admissible evidence links, while the projection makes most semantics
  opaque or omits them. The Value ceiling is both estimator- and
  information-limited, with observability the prior architectural bottleneck.
- BestOfN and PUCT are Phase 5.5 `CO-CHAMPIONS`: BestOfN is the stronger
  complexity-adjusted anchor; PUCT has lower regret and remains an unproven,
  depth/value-limited, cost-disadvantaged research baseline.
- RL is `NOT YET EARNED`; learned Value and learned Policy are premature. There
  is no canonical recursive successor executor, real counterfactual trajectory
  set, governed reward, or trustworthy learned-Policy target.
- Phase 5.5 selects exactly one next milestone:
  `feature/socrates-zero-canonical-observability-v1`. It tests whether an
  opt-in typed v1 projection can separate real governing states aliased by v0.
  The experiment freezes every Phase 5 component and initially adds no new
  Value, search, successor, provider, shadow, training, or production behavior.
- Completed verification: evaluation `37`; PUCT `53`; BestOfN `24`; Greedy
  `27`; Policy `13`; Value `21`; contracts/strategies `123`; SocratesZero
  `239`; Hybrid H8 + SocratesZero `250`; focused CED/Socratic `142`;
  `tests_dialogues` `2305 passed, 1 skipped`; repository-wide `2612 passed,
  1 skipped, 23 pre-existing warnings`.
- Phase 5.5 is complete as documentation-only analysis. NEXT, if separately
  authorized, is canonical epistemic observability v1—not depth two, shadow
  collection, learned Value/Policy, RL, or production wiring.

## Protected local state

Two pre-existing untracked files are outside this branch's work and must remain
untouched:

- `scripts/live_dialogue.py.bak`
- the malformed root filename beginning `ocratic_followup_mandate`
