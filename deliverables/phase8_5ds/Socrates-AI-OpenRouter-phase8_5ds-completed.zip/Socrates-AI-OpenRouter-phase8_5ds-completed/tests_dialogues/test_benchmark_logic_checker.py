"""The benchmark evaluator, and the offline scoring of the recorded H10 answer.

No paid call: the H10 answer is quoted from the recorded run.
"""

from __future__ import annotations

import ast
import pathlib

from tests_dialogues.benchmark_logic_checker import (
    PARTICIPANTS,
    BenchmarkVerdict,
    evaluate_answer,
    satisfies_constraints,
    valid_orders,
)

#: Verbatim opening of the core_answer the H10 live run produced.
H10_ANSWER = (
    "The information provided is insufficient to determine a unique presentation "
    "order due to the ambiguity in the interpretation of 'before' in the "
    "constraint 'Anna presents before Ben.' This ambiguity affects the possible "
    "presentation orders, and without further clarification the order cannot be "
    "fixed."
)


def test_the_constraints_admit_exactly_one_order():
    """Enumerated independently, not read from the fixture."""
    solutions = valid_orders()
    assert solutions == [("Anna", "Ben", "Clara", "David")]
    assert len(solutions) == 1


def test_each_constraint_actually_bites():
    assert satisfies_constraints(("Anna", "Ben", "Clara", "David")) is True
    # Ben before Anna violates constraint 1.
    assert satisfies_constraints(("Ben", "Anna", "Clara", "David")) is False
    # Clara not immediately before David violates constraint 2.
    assert satisfies_constraints(("Clara", "Anna", "Ben", "David")) is False
    # C-D-A-B puts Ben last, violating constraint 3. This is the counterexample
    # the frozen elenchus failed to reject.
    assert satisfies_constraints(("Clara", "David", "Anna", "Ben")) is False


def test_the_checker_separates_all_four_outcomes():
    correct, _ = evaluate_answer(
        "The unique order is Anna, then Ben, then Clara, then David.")
    assert correct is BenchmarkVerdict.CORRECT_UNIQUE

    multiple, _ = evaluate_answer(
        "The information is insufficient; several valid orders exist.")
    assert multiple is BenchmarkVerdict.INCORRECT_MULTIPLE

    invalid, _ = evaluate_answer("The order is Clara, David, Anna, Ben.")
    assert invalid is BenchmarkVerdict.INVALID_PERMUTATION

    missing, _ = evaluate_answer("Constraints are interesting to consider.")
    assert missing is BenchmarkVerdict.MISSING_CONCLUSION


def test_surface_name_presence_is_not_enough_to_score_correct():
    """The defect in the first checker: all four names, and a wrong answer."""
    verdict, _ = evaluate_answer(
        "Considering Anna, Ben, Clara and David, the order cannot be determined.")
    assert verdict is BenchmarkVerdict.INCORRECT_MULTIPLE


def test_the_recorded_h10_answer_scores_as_a_failure():
    """The live council was wrong. Scored offline, from the recorded text."""
    verdict, reason = evaluate_answer(H10_ANSWER)
    assert verdict is BenchmarkVerdict.INCORRECT_MULTIPLE
    assert "underdetermined" in reason
    assert verdict is not BenchmarkVerdict.CORRECT_UNIQUE


#: Verbatim core_answer from the Level-3 live run. The council was CORRECT here.
LEVEL3_ANSWER = (
    "Given the constraints that Anna (A) must present before Ben (B), Clara (C) "
    "must present immediately before David (D), and Ben cannot be last, the "
    "unique presentation order is Anna, Ben, Clara, David (A, B, C, D). This "
    "order satisfies all constraints: A precedes B, C immediately precedes D, "
    "and B is not last."
)


def test_restating_the_constraints_does_not_invent_a_phantom_order():
    """The checker's second failure, pinned.

    Scanning any four-name window read "Clara ... David ... Ben ... Anna" out of
    the constraint restatement and scored a correct live answer as wrong. Only
    separators may sit between the names of an asserted order.
    """
    from tests_dialogues.benchmark_logic_checker import _named_orders
    assert _named_orders(LEVEL3_ANSWER) == [("Anna", "Ben", "Clara", "David")]


def test_the_level3_live_answer_scores_as_correct():
    verdict, _ = evaluate_answer(LEVEL3_ANSWER)
    assert verdict is BenchmarkVerdict.CORRECT_UNIQUE


def test_the_tightened_checker_still_fails_the_h10_answer():
    """Tightening must not have made it lenient again."""
    verdict, _ = evaluate_answer(H10_ANSWER)
    assert verdict is BenchmarkVerdict.INCORRECT_MULTIPLE


def test_the_checker_is_not_imported_by_any_runtime_module():
    """Puzzle-specific logic must never reach CED or the hybrid core."""
    backend = pathlib.Path(__file__).resolve().parents[1] / "backend"
    offenders = []
    for path in backend.rglob("*.py"):
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError:                      # pragma: no cover - defensive
            continue
        for node in ast.walk(tree):
            names = []
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                names = [node.module or ""] + [a.name for a in node.names]
            if any("benchmark_logic_checker" in n for n in names):
                offenders.append(path.relative_to(backend).as_posix())
                break
    assert offenders == [], f"runtime imports benchmark code: {offenders}"


def test_participants_match_the_frozen_fixture():
    import json
    fixture = json.loads(
        (pathlib.Path(__file__).parent / "fixtures" / "known_failures"
         / "current_canonical_repeat_003.json").read_text(encoding="utf-8"))
    assert sorted(fixture["benchmark"]["participants"]) == sorted(PARTICIPANTS)
    assert fixture["benchmark"]["ground_truth"]["valid_orders"] == [list(valid_orders()[0])]


#: Verbatim core_answer from the SECOND Level-3 live run. Also correct, and it
#: names a wrong order explicitly in order to refute it.
LEVEL3_RUN2_ANSWER = (
    "The unique presentation order given the constraints is Anna, Ben, Clara, "
    "David (A B C D). This order satisfies all constraints: Anna presents "
    "before Ben, Clara presents immediately before David, and Ben is not last. "
    "Among the permutations with Clara immediately before David (A B C D, "
    "A C D B, C D A B, C D B A), only A B C D satisfies all constraints. The "
    "synthesizer's claim that the order is Anna, Clara, David, Ben (A C D B) "
    "is incorrect because it violates the 'Ben is not last' constraint."
)


def test_an_order_named_in_order_to_refute_it_is_not_asserted():
    """The checker's third failure, pinned.

    The council reasoned well: it enumerated the candidates and rejected
    A-C-D-B by name, citing the constraint it breaks. The checker read the
    rejected order as a second asserted answer and scored a correct reply wrong.
    """
    from tests_dialogues.benchmark_logic_checker import _named_orders
    assert _named_orders(LEVEL3_RUN2_ANSWER) == [("Anna", "Ben", "Clara", "David")]


def test_the_second_level3_live_answer_scores_as_correct():
    verdict, _ = evaluate_answer(LEVEL3_RUN2_ANSWER)
    assert verdict is BenchmarkVerdict.CORRECT_UNIQUE


def test_constraint_language_is_not_read_as_refutation():
    """"Ben cannot be last" states a constraint; it rejects no named order."""
    verdict, _ = evaluate_answer(
        "Since Ben cannot be last, the order is Anna, Ben, Clara, David.")
    assert verdict is BenchmarkVerdict.CORRECT_UNIQUE


def test_a_genuinely_refuted_only_answer_has_no_conclusion():
    verdict, _ = evaluate_answer(
        "The order Anna, Clara, David, Ben is incorrect because it violates "
        "the last constraint.")
    assert verdict is BenchmarkVerdict.MISSING_CONCLUSION
